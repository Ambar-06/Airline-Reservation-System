# CSS only cool hover effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/t_afif/pen/ExQLWNE](https://codepen.io/t_afif/pen/ExQLWNE).

CSS Tip!
https://twitter.com/ChallengesCss/status/1531955787500859394